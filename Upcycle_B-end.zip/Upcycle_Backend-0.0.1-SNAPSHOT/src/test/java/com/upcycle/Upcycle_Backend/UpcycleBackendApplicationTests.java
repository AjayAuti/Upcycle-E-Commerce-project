package com.upcycle.Upcycle_Backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UpcycleBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
